enum Foo {
    case Bar(baz: Int? = nil, quux: Int)
}

func printFoo(param: Foo) {
    print(param)
}

someFunc(.Bar(quux: 42))
